"""
main.py
-------
FastAPI application ka entry point.

Yahan hum:
  1. App instance banate hain
  2. CORS configure karte hain
  3. Saare routes register karte hain
  4. Database tables create karte hain (startup pe)
  5. Global exception handlers add karte hain
"""

from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError

from app.database import engine
from app import models
from app.routes import auth, users, transactions, analytics

# ──────────────────────────────────────────────
# Database tables create karo (agar exist nahi karte)
# ──────────────────────────────────────────────
models.Base.metadata.create_all(bind=engine)

# ──────────────────────────────────────────────
# FastAPI App Instance
# ──────────────────────────────────────────────
app = FastAPI(
    title="💰 Finance Tracker API",
    description="""
## Personal Finance Management System

Ye API aapko apne income aur expenses track karne mein help karta hai.

### Features:
- 🔐 JWT-based Authentication
- 👤 Role-Based Access Control (Viewer / Analyst / Admin)
- 💰 Full Transaction CRUD
- 🔍 Advanced Filtering & Pagination
- 📊 Analytics & Summary Reports

### User Roles:
| Role     | Permissions                                      |
|----------|--------------------------------------------------|
| Viewer   | Sirf apne transactions dekh sakta hai           |
| Analyst  | Transactions + filtering + analytics             |
| Admin    | Full CRUD + user management + all data           |

### Quick Start:
1. `/api/auth/register` se account banao
2. `/api/auth/login` se JWT token lo
3. Token ko `Authorization: Bearer <token>` header mein bhejo
    """,
    version="1.0.0",
    contact={
        "name": "Finance Tracker",
        "email": "admin@financetracker.com",
    },
    license_info={
        "name": "MIT",
    },
)

# ──────────────────────────────────────────────
# CORS Middleware
# In production: allowed_origins mein sirf apna domain do
# ──────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # Development mein sabhi allow
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ──────────────────────────────────────────────
# Register Routes
# ──────────────────────────────────────────────
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(transactions.router)
app.include_router(analytics.router)

# ──────────────────────────────────────────────
# Global Exception Handlers
# ──────────────────────────────────────────────

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Pydantic validation error ko clean format mein return karo.
    Default FastAPI format thoda complex hota hai — ye use-friendly hai.
    """
    errors = []
    for error in exc.errors():
        field = " → ".join(str(loc) for loc in error["loc"] if loc != "body")
        errors.append({
            "field": field or "request",
            "message": error["msg"],
            "type": error["type"],
        })

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "message": "Validation failed. Please check your input.",
            "errors": errors,
        },
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Unexpected errors ke liye friendly message."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "message": "Internal server error. Please try again.",
            "detail": str(exc),
        },
    )


# ──────────────────────────────────────────────
# Root Endpoint
# ──────────────────────────────────────────────

@app.get("/", tags=["🏠 Home"], summary="API Health Check")
def root():
    return {
        "message": "Welcome to Finance Tracker API 💰",
        "status": "running",
        "docs": "/docs",
        "redoc": "/redoc",
        "version": "1.0.0",
    }


@app.get("/health", tags=["🏠 Home"], summary="Health check")
def health_check():
    return {"status": "healthy", "database": "connected"}
