"""
routes/auth.py
--------------
Authentication routes:
  POST /api/auth/register  — naya account banao
  POST /api/auth/login     — token lo
  GET  /api/auth/me        — apni info dekho
"""

from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas import UserCreate, UserResponse, Token, MessageResponse
from app.services.user_service import UserService
from app.core.security import create_access_token
from app.core.dependencies import get_current_user
from app.models import User

router = APIRouter(prefix="/api/auth", tags=["🔐 Authentication"])


@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register new user",
    description="Naya user account banao. Default role: viewer."
)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    return UserService.create_user(db, user_data)


@router.post(
    "/login",
    response_model=Token,
    summary="Login & get JWT token",
    description="Username aur password do, JWT access token lo."
)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    OAuth2PasswordRequestForm use karta hai — Swagger UI mein
    automatic login form dikhega. Fields: username, password.
    """
    user = UserService.authenticate_user(db, form_data.username, form_data.password)
    token = create_access_token(data={"sub": user.username, "role": user.role})
    return Token(access_token=token)


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current user info",
    description="Apni profile dekho (requires valid token)."
)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user
