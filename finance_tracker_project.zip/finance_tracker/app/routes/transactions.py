"""
routes/transactions.py
-----------------------
Financial transaction CRUD routes.

Role matrix:
  Action          | Viewer | Analyst | Admin
  --------------- | ------ | ------- | -----
  List/Read       |   ✅   |   ✅    |  ✅
  Filter          |   ❌   |   ✅    |  ✅
  Create          |   ❌   |   ❌    |  ✅
  Update          |   ❌   |   ❌    |  ✅
  Delete          |   ❌   |   ❌    |  ✅
"""

from datetime import date
from typing import Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, TransactionType
from app.schemas import (
    TransactionCreate,
    TransactionUpdate,
    TransactionResponse,
    TransactionFilter,
    PaginatedResponse,
    MessageResponse,
)
from app.services.transaction_service import TransactionService
from app.core.dependencies import get_current_user, require_analyst, require_admin
import math

router = APIRouter(prefix="/api/transactions", tags=["💰 Transactions"])


@router.post(
    "",
    response_model=TransactionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create transaction [Admin only]",
)
def create_transaction(
    data: TransactionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """
    Naya income ya expense record banao.
    Amount, type, category, date required hain.
    """
    return TransactionService.create_transaction(db, data, current_user)


@router.get(
    "",
    response_model=PaginatedResponse,
    summary="List transactions with filters [Analyst/Admin]",
)
def list_transactions(
    # ── Filters (query params) ──────────────────────────────
    type: Optional[TransactionType] = Query(None, description="income ya expense"),
    category: Optional[str] = Query(None, description="Category name (partial match)"),
    start_date: Optional[date] = Query(None, description="Filter from date (YYYY-MM-DD)"),
    end_date: Optional[date] = Query(None, description="Filter to date (YYYY-MM-DD)"),
    # ── Pagination ──────────────────────────────────────────
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(default=20, ge=1, le=100, description="Items per page"),
    # ── Dependencies ────────────────────────────────────────
    db: Session = Depends(get_db),
    current_user: User = Depends(require_analyst),
):
    """
    Saare transactions list karo with optional filters aur pagination.
    Viewer ke liye ye route access nahi hai.
    """
    filters = TransactionFilter(
        type=type,
        category=category,
        start_date=start_date,
        end_date=end_date,
        page=page,
        page_size=page_size,
    )
    items, total = TransactionService.get_transactions(db, filters, current_user)
    total_pages = math.ceil(total / page_size) if total > 0 else 0

    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.get(
    "/my",
    response_model=PaginatedResponse,
    summary="Get MY transactions [All roles]",
)
def my_transactions(
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Viewer bhi apne transactions dekh sakta hai is route se.
    Filtering nahi milegi — sirf apna data, sabhi records.
    """
    filters = TransactionFilter(page=page, page_size=page_size)
    items, total = TransactionService.get_transactions(db, filters, current_user)
    total_pages = math.ceil(total / page_size) if total > 0 else 0

    return PaginatedResponse(
        items=items,
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
    )


@router.get(
    "/{transaction_id}",
    response_model=TransactionResponse,
    summary="Get single transaction [All roles]",
)
def get_transaction(
    transaction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return TransactionService.get_transaction_by_id(db, transaction_id, current_user)


@router.put(
    "/{transaction_id}",
    response_model=TransactionResponse,
    summary="Update transaction [Admin only]",
)
def update_transaction(
    transaction_id: int,
    update_data: TransactionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    """
    Partial update — sirf jo fields bhejo wahi update hongi.
    Baaki fields unchanged rahenge.
    """
    return TransactionService.update_transaction(db, transaction_id, update_data, current_user)


@router.delete(
    "/{transaction_id}",
    response_model=MessageResponse,
    summary="Delete transaction [Admin only]",
)
def delete_transaction(
    transaction_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    TransactionService.delete_transaction(db, transaction_id, current_user)
    return MessageResponse(message=f"Transaction {transaction_id} deleted successfully.")
