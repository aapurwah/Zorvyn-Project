"""
routes/analytics.py
--------------------
Analytics/Summary routes — Analyst + Admin only.

  GET /api/analytics/summary             — full overview
  GET /api/analytics/categories          — category breakdown
  GET /api/analytics/monthly/{year}/{month} — month detail
"""

from fastapi import APIRouter, Depends, Path, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, TransactionType
from app.schemas import AnalyticsSummary
from app.services.analytics_service import AnalyticsService
from app.core.dependencies import require_analyst

router = APIRouter(prefix="/api/analytics", tags=["📊 Analytics"])


@router.get(
    "/summary",
    response_model=AnalyticsSummary,
    summary="Full financial summary [Analyst/Admin]",
    description="""
    Poora financial overview ek hi call mein:
    - Total income, expenses, balance
    - Category-wise breakdown (with %)
    - Month-wise summary
    - Last 10 transactions
    """,
)
def get_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_analyst),
):
    return AnalyticsService.get_summary(db, current_user)


@router.get(
    "/categories",
    summary="Category breakdown [Analyst/Admin]",
    description="Kisi ek type (income/expense) ka category breakdown.",
)
def get_category_breakdown(
    type: TransactionType = Query(..., description="income ya expense"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_analyst),
):
    return AnalyticsService.get_category_summary(db, current_user, type)


@router.get(
    "/monthly/{year}/{month}",
    summary="Monthly detail [Analyst/Admin]",
    description="Kisi specific month ke saare transactions aur summary.",
)
def get_monthly_detail(
    year: int = Path(..., ge=2000, le=2100, description="Year (e.g. 2024)"),
    month: int = Path(..., ge=1, le=12, description="Month (1-12)"),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_analyst),
):
    return AnalyticsService.get_monthly_detail(db, current_user, year, month)
