"""
routes/users.py
---------------
User management routes — ADMIN ONLY (except /me)

  GET    /api/users          — list all users (admin)
  GET    /api/users/{id}     — get specific user (admin)
  PUT    /api/users/{id}     — update role/status (admin)
  DELETE /api/users/{id}     — delete user (admin)
"""

from typing import List
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas import UserResponse, UserUpdate, MessageResponse
from app.services.user_service import UserService
from app.core.dependencies import require_admin, get_current_user
from app.models import User

router = APIRouter(prefix="/api/users", tags=["👤 User Management"])


@router.get(
    "",
    response_model=List[UserResponse],
    summary="List all users [Admin only]",
)
def list_users(
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return UserService.get_all_users(db, skip=skip, limit=limit)


@router.get(
    "/{user_id}",
    response_model=UserResponse,
    summary="Get user by ID [Admin only]",
)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_admin),
):
    return UserService.get_user_by_id(db, user_id)


@router.put(
    "/{user_id}",
    response_model=UserResponse,
    summary="Update user role/status [Admin only]",
)
def update_user(
    user_id: int,
    update_data: UserUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    return UserService.update_user(db, user_id, update_data, current_user)


@router.delete(
    "/{user_id}",
    response_model=MessageResponse,
    summary="Delete user [Admin only]",
)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    UserService.delete_user(db, user_id, current_user)
    return MessageResponse(message=f"User {user_id} successfully deleted.")
