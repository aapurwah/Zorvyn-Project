"""
schemas.py
----------
Pydantic models = request/response ka blueprint.
"""

import datetime as dt
from typing import Optional, List
from pydantic import BaseModel, EmailStr, Field, field_validator
from app.models import UserRole, TransactionType


# ══════════════════════════════════════════════
# USER SCHEMAS
# ══════════════════════════════════════════════

class UserBase(BaseModel):
    username: str = Field(..., min_length=3, max_length=50, examples=["john_doe"])
    email: EmailStr = Field(..., examples=["john@example.com"])


class UserCreate(UserBase):
    password: str = Field(..., min_length=6)
    role: UserRole = Field(default=UserRole.viewer)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if v.isdigit():
            raise ValueError("Password sirf numbers ka nahi ho sakta")
        return v


class UserUpdate(BaseModel):
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase):
    id: int
    role: UserRole
    is_active: bool
    created_at: dt.datetime
    model_config = {"from_attributes": True}


# ══════════════════════════════════════════════
# TRANSACTION SCHEMAS
# ══════════════════════════════════════════════

class TransactionBase(BaseModel):
    amount: float = Field(..., gt=0, examples=[5000.0])
    type: TransactionType = Field(..., examples=["income"])
    category: str = Field(..., min_length=1, max_length=100, examples=["Salary"])
    transaction_date: dt.date = Field(default=None, examples=["2024-01-15"])
    notes: Optional[str] = Field(None, max_length=500)

    def model_post_init(self, __context):
        if self.transaction_date is None:
            object.__setattr__(self, "transaction_date", dt.date.today())


class TransactionCreate(TransactionBase):
    pass


class TransactionUpdate(BaseModel):
    amount: Optional[float] = Field(None, gt=0)
    type: Optional[TransactionType] = None
    category: Optional[str] = Field(None, min_length=1, max_length=100)
    transaction_date: Optional[dt.date] = None
    notes: Optional[str] = Field(None, max_length=500)


class TransactionResponse(BaseModel):
    id: int
    amount: float
    type: TransactionType
    category: str
    transaction_date: dt.date
    notes: Optional[str]
    user_id: int
    created_at: dt.datetime
    updated_at: dt.datetime
    model_config = {"from_attributes": True}


# ══════════════════════════════════════════════
# FILTER SCHEMAS
# ══════════════════════════════════════════════

class TransactionFilter(BaseModel):
    type: Optional[TransactionType] = None
    category: Optional[str] = None
    start_date: Optional[dt.date] = None
    end_date: Optional[dt.date] = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)


# ══════════════════════════════════════════════
# ANALYTICS SCHEMAS
# ══════════════════════════════════════════════

class CategoryBreakdown(BaseModel):
    category: str
    total: float
    count: int
    percentage: float


class MonthlySummary(BaseModel):
    year: int
    month: int
    month_name: str
    total_income: float
    total_expenses: float
    net: float


class AnalyticsSummary(BaseModel):
    total_income: float
    total_expenses: float
    current_balance: float
    total_transactions: int
    income_breakdown: List[CategoryBreakdown]
    expense_breakdown: List[CategoryBreakdown]
    monthly_summary: List[MonthlySummary]
    recent_transactions: List[TransactionResponse]


# ══════════════════════════════════════════════
# AUTH SCHEMAS
# ══════════════════════════════════════════════

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[UserRole] = None


# ══════════════════════════════════════════════
# GENERIC WRAPPERS
# ══════════════════════════════════════════════

class PaginatedResponse(BaseModel):
    items: List[TransactionResponse]
    total: int
    page: int
    page_size: int
    total_pages: int


class MessageResponse(BaseModel):
    message: str
    success: bool = True
