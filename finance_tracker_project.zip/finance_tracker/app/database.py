"""
database.py
-----------
Yahan hum SQLite database ka setup karte hain SQLAlchemy ke through.
SQLAlchemy ek ORM (Object Relational Mapper) hai — iska matlab hai
hum Python objects use karke database se baat kar sakte hain,
seedha SQL likhne ki zaroorat nahi.
"""

from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# SQLite database file ka path — project root mein finance.db file banega
DATABASE_URL = "sqlite:///./finance.db"

# Engine = database ke saath actual connection
# connect_args is required for SQLite to work with FastAPI's async nature
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)

# SessionLocal = har request ke liye ek naya database session
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base = sabhi models isko inherit karenge
Base = declarative_base()


def get_db():
    """
    FastAPI dependency — ye function har API request ke saath ek
    fresh database session deta hai, aur request complete hone ke
    baad automatically close kar deta hai (try/finally pattern).
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
