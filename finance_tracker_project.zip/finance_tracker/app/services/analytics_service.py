"""
services/analytics_service.py
-------------------------------
Finance analytics ka poora logic yahan hai.

Calculations:
  - Total income / expenses / balance
  - Category-wise breakdown (with percentage)
  - Month-wise summary
  - Recent transactions
"""

import calendar
import datetime as dt
from collections import defaultdict
from typing import List
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.models import Transaction, User, UserRole, TransactionType
from app.schemas import (
    AnalyticsSummary,
    CategoryBreakdown,
    MonthlySummary,
    TransactionResponse,
)


class AnalyticsService:

    @staticmethod
    def _get_base_query(db: Session, current_user: User):
        """
        Admin = sabke data ka analysis
        Others = sirf apna data
        """
        query = db.query(Transaction)
        if current_user.role != UserRole.admin:
            query = query.filter(Transaction.user_id == current_user.id)
        return query

    @staticmethod
    def get_summary(db: Session, current_user: User) -> AnalyticsSummary:
        """
        Full analytics summary:
          1. Total income/expense/balance
          2. Category breakdown
          3. Monthly summary
          4. Recent 10 transactions
        """
        base_query = AnalyticsService._get_base_query(db, current_user)
        all_transactions = base_query.all()

        # ── Step 1: Basic totals ──────────────────────────────────────
        total_income = sum(t.amount for t in all_transactions if t.type == TransactionType.income)
        total_expenses = sum(t.amount for t in all_transactions if t.type == TransactionType.expense)
        current_balance = total_income - total_expenses

        # ── Step 2: Category breakdown ────────────────────────────────
        income_by_cat: dict = defaultdict(lambda: {"total": 0.0, "count": 0})
        expense_by_cat: dict = defaultdict(lambda: {"total": 0.0, "count": 0})

        for t in all_transactions:
            if t.type == TransactionType.income:
                income_by_cat[t.category]["total"] += t.amount
                income_by_cat[t.category]["count"] += 1
            else:
                expense_by_cat[t.category]["total"] += t.amount
                expense_by_cat[t.category]["count"] += 1

        def build_breakdown(cat_dict: dict, total: float) -> List[CategoryBreakdown]:
            result = []
            for cat, data in sorted(cat_dict.items(), key=lambda x: -x[1]["total"]):
                result.append(CategoryBreakdown(
                    category=cat,
                    total=round(data["total"], 2),
                    count=data["count"],
                    percentage=round((data["total"] / total * 100) if total > 0 else 0, 1)
                ))
            return result

        income_breakdown = build_breakdown(income_by_cat, total_income)
        expense_breakdown = build_breakdown(expense_by_cat, total_expenses)

        # ── Step 3: Monthly summary ───────────────────────────────────
        monthly_data: dict = defaultdict(lambda: {"income": 0.0, "expense": 0.0})

        for t in all_transactions:
            key = (t.transaction_date.year, t.transaction_date.month)
            if t.type == TransactionType.income:
                monthly_data[key]["income"] += t.amount
            else:
                monthly_data[key]["expense"] += t.amount

        monthly_summary = []
        for (year, month), data in sorted(monthly_data.items(), reverse=True):
            monthly_summary.append(MonthlySummary(
                year=year,
                month=month,
                month_name=calendar.month_name[month],  # "January", "February" etc.
                total_income=round(data["income"], 2),
                total_expenses=round(data["expense"], 2),
                net=round(data["income"] - data["expense"], 2),
            ))

        # ── Step 4: Recent 10 transactions ───────────────────────────
        recent = (
            AnalyticsService._get_base_query(db, current_user)
            .order_by(Transaction.transaction_date.desc(), Transaction.created_at.desc())
            .limit(10)
            .all()
        )

        return AnalyticsSummary(
            total_income=round(total_income, 2),
            total_expenses=round(total_expenses, 2),
            current_balance=round(current_balance, 2),
            total_transactions=len(all_transactions),
            income_breakdown=income_breakdown,
            expense_breakdown=expense_breakdown,
            monthly_summary=monthly_summary,
            recent_transactions=[TransactionResponse.model_validate(t) for t in recent],
        )

    @staticmethod
    def get_category_summary(db: Session, current_user: User, transaction_type: TransactionType):
        """Sirf ek type (income/expense) ka category breakdown."""
        base_query = AnalyticsService._get_base_query(db, current_user)
        transactions = base_query.filter(Transaction.type == transaction_type).all()

        total = sum(t.amount for t in transactions)
        cat_dict: dict = defaultdict(lambda: {"total": 0.0, "count": 0})

        for t in transactions:
            cat_dict[t.category]["total"] += t.amount
            cat_dict[t.category]["count"] += 1

        result = []
        for cat, data in sorted(cat_dict.items(), key=lambda x: -x[1]["total"]):
            result.append(CategoryBreakdown(
                category=cat,
                total=round(data["total"], 2),
                count=data["count"],
                percentage=round((data["total"] / total * 100) if total > 0 else 0, 1)
            ))
        return result

    @staticmethod
    def get_monthly_detail(db: Session, current_user: User, year: int, month: int):
        """Kisi specific month ka detail."""
        start = dt.date(year, month, 1)
        last_day = calendar.monthrange(year, month)[1]
        end = dt.date(year, month, last_day)

        transactions = (
            AnalyticsService._get_base_query(db, current_user)
            .filter(Transaction.transaction_date >= start, Transaction.transaction_date <= end)
            .order_by(Transaction.transaction_date.asc())
            .all()
        )

        income = sum(t.amount for t in transactions if t.type == TransactionType.income)
        expense = sum(t.amount for t in transactions if t.type == TransactionType.expense)

        return {
            "year": year,
            "month": month,
            "month_name": calendar.month_name[month],
            "total_income": round(income, 2),
            "total_expenses": round(expense, 2),
            "net": round(income - expense, 2),
            "transaction_count": len(transactions),
            "transactions": [TransactionResponse.model_validate(t) for t in transactions],
        }
