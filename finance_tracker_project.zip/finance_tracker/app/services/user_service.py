"""
services/user_service.py
------------------------
User-related business logic yahan hai.
Routes sirf HTTP handle karte hain — actual kaam service mein hota hai.

Ye pattern "Service Layer" pattern hai — real companies mein use hota hai.
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from app.models import User, UserRole
from app.schemas import UserCreate, UserUpdate
from app.core.security import hash_password, verify_password


class UserService:

    @staticmethod
    def create_user(db: Session, user_data: UserCreate) -> User:
        """
        Naya user banao.
        Pehle check karo ki username/email already exist to nahi karta.
        """
        # Duplicate username check
        if db.query(User).filter(User.username == user_data.username).first():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Username '{user_data.username}' already taken. Please choose another."
            )

        # Duplicate email check
        if db.query(User).filter(User.email == user_data.email).first():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Email '{user_data.email}' is already registered."
            )

        # Password hash karke store karo — kabhi plain text store mat karo!
        new_user = User(
            username=user_data.username,
            email=user_data.email,
            hashed_password=hash_password(user_data.password),
            role=user_data.role,
        )
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        return new_user

    @staticmethod
    def get_user_by_id(db: Session, user_id: int) -> User:
        """ID se user fetch karo, nahi mila to 404."""
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User with id={user_id} not found."
            )
        return user

    @staticmethod
    def get_user_by_username(db: Session, username: str) -> Optional[User]:
        """Login ke liye username se user dhundho."""
        return db.query(User).filter(User.username == username).first()

    @staticmethod
    def get_all_users(db: Session, skip: int = 0, limit: int = 50) -> List[User]:
        """Saare users list karo (admin only)."""
        return db.query(User).offset(skip).limit(limit).all()

    @staticmethod
    def update_user(db: Session, user_id: int, update_data: UserUpdate, requesting_user: User) -> User:
        """
        User ka role ya active status update karo.
        Admin apna khud ka role nahi badal sakta (protection).
        """
        user = UserService.get_user_by_id(db, user_id)

        # Self-demotion protection
        if requesting_user.id == user_id and update_data.role and update_data.role != UserRole.admin:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Admin apna khud ka role remove nahi kar sakta."
            )

        if update_data.role is not None:
            user.role = update_data.role
        if update_data.is_active is not None:
            user.is_active = update_data.is_active

        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def delete_user(db: Session, user_id: int, requesting_user: User) -> None:
        """
        User delete karo.
        Admin apna account delete nahi kar sakta.
        """
        user = UserService.get_user_by_id(db, user_id)

        if requesting_user.id == user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Aap apna khud ka account delete nahi kar sakte."
            )

        db.delete(user)
        db.commit()

    @staticmethod
    def authenticate_user(db: Session, username: str, password: str) -> User:
        """
        Login logic:
          1. Username se user dhundho
          2. Password verify karo
          3. Active status check karo
        """
        user = UserService.get_user_by_username(db, username)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password."
            )

        if not verify_password(password, user.hashed_password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password."
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account deactivated. Contact admin."
            )

        return user
