"""
services/transaction_service.py
--------------------------------
Transaction CRUD ka business logic.

Important rule:
  - Viewer aur Analyst sirf apne transactions dekh sakte hain
  - Admin sabke transactions dekh sakta hai
  - Create/Update/Delete sirf Admin kar sakta hai
"""

from typing import List, Tuple
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import and_
from fastapi import HTTPException, status

from app.models import Transaction, User, UserRole, TransactionType
from app.schemas import TransactionCreate, TransactionUpdate, TransactionFilter


class TransactionService:

    @staticmethod
    def create_transaction(db: Session, data: TransactionCreate, current_user: User) -> Transaction:
        """
        Naya transaction create karo.
        user_id automatically current logged-in user ka lagega.
        """
        transaction = Transaction(
            amount=data.amount,
            type=data.type,
            category=data.category.strip().title(),  # "food" → "Food" (clean input)
            transaction_date=data.transaction_date,
            notes=data.notes,
            user_id=current_user.id,
        )
        db.add(transaction)
        db.commit()
        db.refresh(transaction)
        return transaction

    @staticmethod
    def _build_query(db: Session, filters: TransactionFilter, current_user: User):
        """
        Private helper: filter conditions ka base query banao.
        Admin = sabke records
        Others = sirf apne records
        """
        query = db.query(Transaction)

        # Role-based data access
        if current_user.role != UserRole.admin:
            query = query.filter(Transaction.user_id == current_user.id)

        # Apply filters
        conditions = []

        if filters.type:
            conditions.append(Transaction.type == filters.type)

        if filters.category:
            # Case-insensitive partial match
            conditions.append(Transaction.category.ilike(f"%{filters.category}%"))

        if filters.start_date:
            conditions.append(Transaction.transaction_date >= filters.start_date)

        if filters.end_date:
            conditions.append(Transaction.transaction_date <= filters.end_date)

        if conditions:
            query = query.filter(and_(*conditions))

        return query.order_by(Transaction.transaction_date.desc(), Transaction.created_at.desc())

    @staticmethod
    def get_transactions(
        db: Session,
        filters: TransactionFilter,
        current_user: User
    ) -> Tuple[List[Transaction], int]:
        """
        Paginated transaction list return karo.
        Returns: (items, total_count)
        """
        query = TransactionService._build_query(db, filters, current_user)

        total = query.count()

        offset = (filters.page - 1) * filters.page_size
        items = query.offset(offset).limit(filters.page_size).all()

        return items, total

    @staticmethod
    def get_transaction_by_id(db: Session, transaction_id: int, current_user: User) -> Transaction:
        """
        ID se ek transaction fetch karo.
        Access control:
          - Admin: koi bhi transaction dekh sakta hai
          - Others: sirf apna transaction
        """
        transaction = db.query(Transaction).filter(Transaction.id == transaction_id).first()

        if not transaction:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Transaction with id={transaction_id} not found."
            )

        # Ownership check (non-admin ke liye)
        if current_user.role != UserRole.admin and transaction.user_id != current_user.id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Aap doosre user ka transaction nahi dekh sakte."
            )

        return transaction

    @staticmethod
    def update_transaction(
        db: Session,
        transaction_id: int,
        update_data: TransactionUpdate,
        current_user: User
    ) -> Transaction:
        """
        Partial update — sirf jo fields di gayi hain whi update hongi.
        Pydantic ka exclude_unset=True iske liye use hota hai.
        """
        transaction = TransactionService.get_transaction_by_id(db, transaction_id, current_user)

        update_dict = update_data.model_dump(exclude_unset=True)

        if "category" in update_dict and update_dict["category"]:
            update_dict["category"] = update_dict["category"].strip().title()

        for field, value in update_dict.items():
            setattr(transaction, field, value)

        db.commit()
        db.refresh(transaction)
        return transaction

    @staticmethod
    def delete_transaction(db: Session, transaction_id: int, current_user: User) -> None:
        """Transaction delete karo (admin only)."""
        transaction = TransactionService.get_transaction_by_id(db, transaction_id, current_user)
        db.delete(transaction)
        db.commit()
