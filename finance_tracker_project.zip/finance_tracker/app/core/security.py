"""
core/security.py
----------------
Authentication ka poora logic yahan hai:
  1. Password hashing (bcrypt)
  2. JWT token create karna
  3. JWT token verify karna

JWT = JSON Web Token
  - Login ke baad server ek signed token deta hai
  - Agle requests mein user ye token bhejta hai
  - Server token verify karke user ko pehchanta hai
  - No session/cookie needed — stateless!
"""

from datetime import datetime, timedelta
from typing import Optional

from jose import JWTError, jwt
from passlib.context import CryptContext

# ──────────────────────────────────────────────
# Config — real app mein ye .env se aana chahiye
# ──────────────────────────────────────────────
SECRET_KEY = "finance-tracker-super-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

# bcrypt context — password hashing ke liye
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# ──────────────────────────────────────────────
# Password helpers
# ──────────────────────────────────────────────

def hash_password(plain_password: str) -> str:
    """Plain text password ko secure hash mein convert karo."""
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Login ke waqt — user ne jo diya vs database mein jo hai."""
    return pwd_context.verify(plain_password, hashed_password)


# ──────────────────────────────────────────────
# JWT helpers
# ──────────────────────────────────────────────

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    JWT token banao.
    data = {"sub": username, "role": role}
    Token mein expiry bhi add hoti hai automatically.
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> Optional[dict]:
    """
    Token verify karo aur andar ka data nikalo.
    Token invalid ya expired ho to None return karo.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None
