"""
core/dependencies.py
--------------------
FastAPI dependencies = reusable code jo routes mein inject hota hai.

Yahan teen main dependencies hain:
  1. get_current_user    — token se user identify karo
  2. require_analyst     — analyst ya admin chahiye
  3. require_admin       — sirf admin allowed

Usage in routes:
  @router.get("/...")
  def some_route(current_user: User = Depends(require_analyst)):
      ...
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, UserRole
from app.core.security import decode_access_token

# OAuth2 scheme — Authorization header mein Bearer token dhundta hai
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """
    Har protected route ye dependency use karta hai.
    Steps:
      1. Header se token lo
      2. Token decode karo
      3. Username nikalo
      4. DB se user fetch karo
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token. Please login again.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception

    username: str = payload.get("sub")
    if username is None:
        raise credentials_exception

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account deactivated. Contact admin."
        )

    return user


def get_current_active_user(current_user: User = Depends(get_current_user)) -> User:
    """Alias — active user guarantee."""
    return current_user


def require_analyst(current_user: User = Depends(get_current_user)) -> User:
    """
    Analyst ya Admin required.
    Viewer agar ye route access kare to 403 milega.
    """
    if current_user.role == UserRole.viewer:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied. Your role '{current_user.role}' cannot access analytics/filters. Analyst or Admin required."
        )
    return current_user


def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """
    Sirf Admin allowed.
    Viewer aur Analyst dono ko 403 milega.
    """
    if current_user.role != UserRole.admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied. Admin role required. Your current role: '{current_user.role}'."
        )
    return current_user
