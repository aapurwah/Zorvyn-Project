"""
models.py
---------
Yahan hum database tables define karte hain Python classes ke roop mein.
Har class = ek table. Har class attribute = ek column.

Tables:
  1. users       — system ke users (with roles)
  2. transactions — financial records (income/expense)
"""

from datetime import datetime, date
from sqlalchemy import (
    Column, Integer, String, Float, Date,
    DateTime, Enum, ForeignKey, Text, Boolean
)
from sqlalchemy.orm import relationship
import enum

from app.database import Base


# ──────────────────────────────────────────────
# Enums — fixed allowed values
# ──────────────────────────────────────────────

class UserRole(str, enum.Enum):
    """Teeno roles define hain yahan."""
    viewer  = "viewer"   # Sirf dekh sakta hai
    analyst = "analyst"  # Dekh sakta + filter + analytics
    admin   = "admin"    # Full access + user management


class TransactionType(str, enum.Enum):
    """Transaction sirf do types ka ho sakta hai."""
    income  = "income"
    expense = "expense"


# ──────────────────────────────────────────────
# User Table
# ──────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id         = Column(Integer, primary_key=True, index=True)
    username   = Column(String(50), unique=True, nullable=False, index=True)
    email      = Column(String(100), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    role       = Column(Enum(UserRole), default=UserRole.viewer, nullable=False)
    is_active  = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # One-to-many: ek user ke multiple transactions
    transactions = relationship("Transaction", back_populates="owner", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<User id={self.id} username={self.username} role={self.role}>"


# ──────────────────────────────────────────────
# Transaction Table
# ──────────────────────────────────────────────

class Transaction(Base):
    __tablename__ = "transactions"

    id         = Column(Integer, primary_key=True, index=True)
    amount     = Column(Float, nullable=False)
    type       = Column(Enum(TransactionType), nullable=False)   # income / expense
    category   = Column(String(100), nullable=False)             # e.g. "Food", "Salary"
    transaction_date = Column(Date, nullable=False, default=date.today)
    notes      = Column(Text, nullable=True)                     # Optional description
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Foreign key: har transaction kisi user ka hai
    user_id    = Column(Integer, ForeignKey("users.id"), nullable=False)
    owner      = relationship("User", back_populates="transactions")

    def __repr__(self):
        return f"<Transaction id={self.id} type={self.type} amount={self.amount}>"
