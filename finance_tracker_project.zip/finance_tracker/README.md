# 💰 Finance Tracker API

A production-ready **Personal Finance Management System** built with **FastAPI**, **SQLAlchemy**, and **SQLite**. Features JWT authentication, role-based access control, full CRUD operations, advanced filtering, and analytics.

---

## 🏗️ Project Structure

```
finance_tracker/
│
├── main.py                          # FastAPI app entry point, route registration
├── seed.py                          # Demo data seeder
├── requirements.txt
│
└── app/
    ├── __init__.py
    ├── database.py                  # SQLAlchemy engine & session setup
    ├── models.py                    # ORM models (User, Transaction)
    ├── schemas.py                   # Pydantic request/response schemas
    │
    ├── core/
    │   ├── __init__.py
    │   ├── security.py              # JWT creation/verification, password hashing
    │   └── dependencies.py          # FastAPI dependencies (auth guards, role checks)
    │
    ├── routes/
    │   ├── __init__.py
    │   ├── auth.py                  # /api/auth — register, login, me
    │   ├── users.py                 # /api/users — user management (admin)
    │   ├── transactions.py          # /api/transactions — CRUD + filters
    │   └── analytics.py             # /api/analytics — summaries & reports
    │
    └── services/
        ├── __init__.py
        ├── user_service.py          # User business logic
        ├── transaction_service.py   # Transaction business logic + filtering
        └── analytics_service.py     # Analytics calculations
```

---

## ⚡ Quick Start

### 1. Clone & Setup

```bash
git clone <your-repo-url>
cd finance_tracker

# Create virtual environment
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# Install dependencies
pip install -r requirements.txt
```

### 2. Run the Server

```bash
uvicorn main:app --reload
```

Server starts at: **http://localhost:8000**

### 3. (Optional) Seed Demo Data

```bash
python seed.py
```

This creates 3 users and 16 sample transactions ready to explore.

### 4. Explore the API

Open **http://localhost:8000/docs** in your browser — full interactive Swagger UI.

---

## 🔐 Authentication

The API uses **JWT Bearer tokens**.

```
1. POST /api/auth/register  →  Create account
2. POST /api/auth/login     →  Get JWT token
3. Add to all requests:  Authorization: Bearer <your_token>
```

---

## 👤 User Roles

| Role     | Permissions |
|----------|-------------|
| `viewer` | View own transactions only |
| `analyst`| View + filter all transactions + analytics |
| `admin`  | Full CRUD + user management + all data |

**Demo credentials** (after running `seed.py`):

| Role     | Username | Password    |
|----------|----------|-------------|
| Admin    | admin    | admin123    |
| Analyst  | analyst  | analyst123  |
| Viewer   | viewer   | viewer123   |

---

## 📋 API Endpoints

### 🔐 Authentication

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Register new user | ❌ |
| POST | `/api/auth/login` | Login, get JWT token | ❌ |
| GET | `/api/auth/me` | Get current user info | ✅ |

### 👤 User Management (Admin Only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | List all users |
| GET | `/api/users/{id}` | Get user by ID |
| PUT | `/api/users/{id}` | Update role/status |
| DELETE | `/api/users/{id}` | Delete user |

### 💰 Transactions

| Method | Endpoint | Role Required | Description |
|--------|----------|---------------|-------------|
| POST | `/api/transactions` | Admin | Create transaction |
| GET | `/api/transactions` | Analyst/Admin | List with filters |
| GET | `/api/transactions/my` | All | View own transactions |
| GET | `/api/transactions/{id}` | All | Get single transaction |
| PUT | `/api/transactions/{id}` | Admin | Update transaction |
| DELETE | `/api/transactions/{id}` | Admin | Delete transaction |

**Query Parameters for `GET /api/transactions`:**

| Parameter | Type | Example | Description |
|-----------|------|---------|-------------|
| `type` | string | `income` | Filter by income/expense |
| `category` | string | `Salary` | Filter by category (partial match) |
| `start_date` | date | `2024-01-01` | Filter from date |
| `end_date` | date | `2024-01-31` | Filter to date |
| `page` | int | `1` | Page number |
| `page_size` | int | `20` | Items per page (max 100) |

### 📊 Analytics (Analyst + Admin)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/analytics/summary` | Full overview: income, expenses, balance, categories, monthly |
| GET | `/api/analytics/categories?type=expense` | Category breakdown for income or expense |
| GET | `/api/analytics/monthly/{year}/{month}` | Detailed breakdown for a specific month |

---

## 📬 Sample API Requests (Postman)

### Register a New User
```http
POST http://localhost:8000/api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "password": "securepass123",
  "role": "analyst"
}
```

### Login
```http
POST http://localhost:8000/api/auth/login
Content-Type: application/x-www-form-urlencoded

username=john_doe&password=securepass123
```

### Create Transaction (Admin)
```http
POST http://localhost:8000/api/transactions
Authorization: Bearer <your_token>
Content-Type: application/json

{
  "amount": 50000,
  "type": "income",
  "category": "Salary",
  "transaction_date": "2024-01-15",
  "notes": "Monthly salary"
}
```

### Filter Transactions
```http
GET http://localhost:8000/api/transactions?type=expense&category=Food&start_date=2024-01-01&end_date=2024-03-31&page=1&page_size=10
Authorization: Bearer <your_token>
```

### Get Full Analytics Summary
```http
GET http://localhost:8000/api/analytics/summary
Authorization: Bearer <your_token>
```

### Get Monthly Detail
```http
GET http://localhost:8000/api/analytics/monthly/2024/1
Authorization: Bearer <your_token>
```

### Update Transaction
```http
PUT http://localhost:8000/api/transactions/1
Authorization: Bearer <your_token>
Content-Type: application/json

{
  "amount": 55000,
  "notes": "Salary + performance bonus"
}
```

---

## 📊 Analytics Response Example

```json
{
  "total_income": 125000.0,
  "total_expenses": 28500.0,
  "current_balance": 96500.0,
  "total_transactions": 12,
  "income_breakdown": [
    { "category": "Salary", "total": 100000.0, "count": 2, "percentage": 80.0 },
    { "category": "Freelance", "total": 25000.0, "count": 2, "percentage": 20.0 }
  ],
  "expense_breakdown": [
    { "category": "Rent", "total": 16000.0, "count": 2, "percentage": 56.1 },
    { "category": "Food", "total": 7500.0, "count": 2, "percentage": 26.3 }
  ],
  "monthly_summary": [
    {
      "year": 2024, "month": 2, "month_name": "February",
      "total_income": 60000.0, "total_expenses": 15200.0, "net": 44800.0
    }
  ],
  "recent_transactions": [...]
}
```

---

## 🧠 Architecture Explained (Hinglish)

### Layers (Clean Architecture):

```
Request → Route → Service → Database
                              ↑
                           Model (ORM)
```

1. **`models.py`** — Database ka blueprint. `User` aur `Transaction` tables define hain.
2. **`schemas.py`** — Pydantic se input/output validate hota hai. Yahan `TransactionCreate`, `UserResponse` jaise classes hain.
3. **`database.py`** — SQLAlchemy engine aur session ka setup.
4. **`core/security.py`** — Password hashing (bcrypt) aur JWT token logic.
5. **`core/dependencies.py`** — FastAPI dependency injection: `require_admin`, `require_analyst`, `get_current_user`.
6. **`services/`** — Business logic yahan hota hai. Routes mein sirf HTTP handling hoti hai.
7. **`routes/`** — URL paths define hote hain. Kaam service ko delegate hota hai.
8. **`main.py`** — Sab kuch ek saath jodta hai.

### JWT Flow:
```
User login karta hai
  → server token banata hai (username + role encoded)
  → user har request mein token bhejta hai
  → server decode karke user identify karta hai
  → role check hota hai → allowed ya 403
```

---

## ⚠️ Validation & Error Codes

| Code | Meaning | Example |
|------|---------|---------|
| 200 | Success | Record fetched |
| 201 | Created | New transaction |
| 400 | Bad Request | Admin deleting own account |
| 401 | Unauthorized | Invalid/expired token |
| 403 | Forbidden | Viewer accessing analytics |
| 404 | Not Found | Transaction ID doesn't exist |
| 409 | Conflict | Duplicate username/email |
| 422 | Validation Error | Negative amount, missing field |

---

## 🔮 Assumptions Made

1. **One user = one set of transactions** — Admin creates transactions assigned to their own user_id. In a real payroll app, an admin would assign to any user.
2. **SQLite for simplicity** — Can be swapped to PostgreSQL/MySQL by just changing `DATABASE_URL`.
3. **No email verification** — Registration is immediate.
4. **Token expiry = 24 hours** — Configurable in `core/security.py`.
5. **Analyst sees admin's transactions** — In a multi-user org, this might be scoped differently.
6. **Category = free text** — No predefined category master table (can be added).

---

## 🚀 Future Improvements

- [ ] PostgreSQL support (change `DATABASE_URL`)
- [ ] Email verification on registration
- [ ] Refresh token support
- [ ] Budget limits per category
- [ ] Export to CSV/Excel
- [ ] Docker & deployment config
- [ ] Rate limiting middleware

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| FastAPI | Web framework |
| SQLAlchemy | ORM |
| SQLite | Database |
| Pydantic v2 | Validation |
| python-jose | JWT |
| passlib + bcrypt | Password hashing |
| uvicorn | ASGI server |
