"""
seed.py
-------
Demo data seed script — project run karne ke baad ye chalao
taaki tumhare paas test karne ke liye ready data ho.

Usage:
  python seed.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal, engine
from app import models
from app.models import User, Transaction, UserRole, TransactionType
from app.core.security import hash_password
from datetime import date

# Tables create karo
models.Base.metadata.create_all(bind=engine)

db = SessionLocal()

def seed():
    # Clear existing data
    db.query(Transaction).delete()
    db.query(User).delete()
    db.commit()

    print("🌱 Seeding database...")

    # ── Users ──────────────────────────────────────────────
    users = [
        User(username="admin",   email="admin@demo.com",   hashed_password=hash_password("admin123"),   role=UserRole.admin),
        User(username="analyst", email="analyst@demo.com", hashed_password=hash_password("analyst123"), role=UserRole.analyst),
        User(username="viewer",  email="viewer@demo.com",  hashed_password=hash_password("viewer123"),  role=UserRole.viewer),
    ]
    for u in users:
        db.add(u)
    db.commit()
    for u in users:
        db.refresh(u)
    print(f"  ✅ Created {len(users)} users")

    admin_id = users[0].id

    # ── Transactions ───────────────────────────────────────
    transactions = [
        # January 2024
        Transaction(amount=50000, type=TransactionType.income,  category="Salary",    transaction_date=date(2024,1,1),  notes="Monthly salary", user_id=admin_id),
        Transaction(amount=8000,  type=TransactionType.expense, category="Rent",      transaction_date=date(2024,1,5),  notes="House rent",     user_id=admin_id),
        Transaction(amount=3500,  type=TransactionType.expense, category="Food",      transaction_date=date(2024,1,10), notes="Groceries",      user_id=admin_id),
        Transaction(amount=5000,  type=TransactionType.income,  category="Freelance", transaction_date=date(2024,1,15), notes="Web project",    user_id=admin_id),
        Transaction(amount=1200,  type=TransactionType.expense, category="Transport", transaction_date=date(2024,1,18),                         user_id=admin_id),
        Transaction(amount=2000,  type=TransactionType.expense, category="Shopping",  transaction_date=date(2024,1,22), notes="Clothes",        user_id=admin_id),
        # February 2024
        Transaction(amount=50000, type=TransactionType.income,  category="Salary",    transaction_date=date(2024,2,1),  notes="Monthly salary", user_id=admin_id),
        Transaction(amount=8000,  type=TransactionType.expense, category="Rent",      transaction_date=date(2024,2,5),                          user_id=admin_id),
        Transaction(amount=4200,  type=TransactionType.expense, category="Food",      transaction_date=date(2024,2,12),                         user_id=admin_id),
        Transaction(amount=8000,  type=TransactionType.income,  category="Freelance", transaction_date=date(2024,2,20), notes="Mobile app",     user_id=admin_id),
        Transaction(amount=3000,  type=TransactionType.expense, category="Utilities", transaction_date=date(2024,2,25), notes="Electricity",    user_id=admin_id),
        # March 2024
        Transaction(amount=55000, type=TransactionType.income,  category="Salary",    transaction_date=date(2024,3,1),  notes="Salary + bonus", user_id=admin_id),
        Transaction(amount=8000,  type=TransactionType.expense, category="Rent",      transaction_date=date(2024,3,5),                          user_id=admin_id),
        Transaction(amount=3800,  type=TransactionType.expense, category="Food",      transaction_date=date(2024,3,15),                         user_id=admin_id),
        Transaction(amount=12000, type=TransactionType.income,  category="Freelance", transaction_date=date(2024,3,22), notes="Design project", user_id=admin_id),
        Transaction(amount=5000,  type=TransactionType.expense, category="Shopping",  transaction_date=date(2024,3,28), notes="Electronics",    user_id=admin_id),
    ]
    for t in transactions:
        db.add(t)
    db.commit()
    print(f"  ✅ Created {len(transactions)} transactions")

    print()
    print("=" * 50)
    print("🎉 Seeding complete! Use these credentials to test:")
    print()
    print("  Role     | Username | Password   ")
    print("  ---------|----------|------------")
    print("  Admin    | admin    | admin123   ")
    print("  Analyst  | analyst  | analyst123 ")
    print("  Viewer   | viewer   | viewer123  ")
    print()
    print("  🚀 Server: http://localhost:8000")
    print("  📖 Docs:   http://localhost:8000/docs")

db.close()

if __name__ == "__main__":
    seed()
